/*
// FlashUP, by Diego F. Goberna, 2010 http://feiss.be
// License: Do what you want with it (although I'd love to know how/where you've use it)
*/

//init function
// parameters: string of the input id, color string ('0x000000' format), label, width, height

function flashup(inputid, color, label, w, h)
{

	var version = getFlashVersion().split(',').shift();
	if(version < 9) return;
	
	if (h===undefined) h= '30';
	if (w===undefined) w= '80';
	if (label===undefined) label= 'Browse...';
	if (color===undefined) color= '0x555555';
	
	var el= document.getElementById(inputid);
	if (el===null || el.form===null) return;
	var action= el.form.action;
		
	var code='<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000"'+
	'codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,0,0"'+ 
	'id="flashup_'+inputid+'" width="'+w+'" height="'+h+'" '+
	'> <param name="allowScriptAccess" value="sameDomain" /> '+
	'<param name="movie" value="flashup.swf" /> '+
	'<param name="quality" value="high" /><param name="bgcolor" value="#FFFFFF" /> '+
	'<param name="FlashVars" VALUE= "label='+label+'&bgcolor='+color+'&action='+action+'"> '+
	'<embed src="flashup.swf" quality="high" bgcolor="#FFFFFF" '+
	'width="'+w+'" height="'+h+'" swLiveConnect="true" id="flashup_'+inputid+'" name="flashup_'+inputid+'" '+
	'allowScriptAccess="sameDomain" type="application/x-shockwave-flash" '+
	'pluginspage="http://www.macromedia.com/go/getflashplayer" '+
	'FlashVars= "label='+label+'&bgcolor='+color+'&action='+action+'" '+
	'/> </object> <div id="flashup_files"></div>';

	el.form.innerHTML= code;

}


//functions called from Flash

function flashup_validFileID(oldid)
{
	return 'file_'+oldid.replace(/[\s\.]/ig, "-");
}

function flashup_fileAdd(filename){
	var el= document.getElementById('flashup_files');
	el.innerHTML+="<div class='flashup_file' id='"+flashup_validFileID(filename)+"'>"+filename+
		"<div class='flashup_progress'><span class='flashup_progress_fill'></span></div></div>";
}
function flashup_fileProgress(filename, progress){
	var f= document.getElementById(flashup_validFileID(filename));
	var span= f.getElementsByTagName('span')[0];
	var w= parseInt(f.getElementsByTagName('div')[0].offsetWidth);
	
	span.style.width= Math.floor(w*progress)+'px';
}
function flashup_fileError(filename, msg){
	var f= document.getElementById(flashup_validFileID(filename));
	f.style.color= 'red';
	f.innerText+=' ('+msg+')';
}
function flashup_fileComplete(filename){
	var f= document.getElementById(flashup_validFileID(filename));
	f.parentNode.removeChild(f);
}

// Flash version detection
// http://www.prodevtips.com/2008/11/20/detecting-flash-player-version-with-javascript/

function getFlashVersion(){
  // ie
	try {
		try {
		  // avoid fp6 minor version lookup issues
		  // see: http://blog.deconcept.com/2006/01/11/getvariable-setvariable-crash-internet-explorer-flash-6/
		  var axo = new ActiveXObject('ShockwaveFlash.ShockwaveFlash.6');
		  try { axo.AllowScriptAccess = 'always'; } catch(e) { return '6,0,0'; }
	} catch(e) {}
	return new ActiveXObject('ShockwaveFlash.ShockwaveFlash').GetVariable('$version').replace(/\D+/g, ',').match(/^,?(.+),?$/)[1];
	// other browsers
	} catch(e) {
		try {
			if(navigator.mimeTypes["application/x-shockwave-flash"].enabledPlugin){
				return (navigator.plugins["Shockwave Flash 2.0"] || navigator.plugins["Shockwave Flash"]).description.replace(/\D+/g, ",").match(/^,?(.+),?$/)[1];
		}
	} catch(e) {}
	}
	return '0,0,0';
}
 
